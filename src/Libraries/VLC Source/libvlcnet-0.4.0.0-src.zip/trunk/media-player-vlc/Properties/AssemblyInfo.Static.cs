using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("DZ.MediaPlayer.Vlc.Tests")]