
This is vlc library files. All of them required to run libvlc.net correctly.

Vlc is open source software licensed under GPLv2 license.
See license.txt for more information.

You can download same vlc libraries or sources here: http://www.videolan.org/